package com.example.myapplication.Interface;

public interface NavigationManager {
    void showFragment(String tittle);
}
